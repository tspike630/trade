# Decision Engine Step 1 — 骨架 + JEV 强度策略 + dry-run

## 原则

- **完全独立进程**：`python -m decision_engine.run`，与 `main.py` 爬虫、`indicators.run` 解耦；崩溃不影响采集 / 指标 / 现有持仓。
- **只决策、不执行**：只生成标准化信号并写入 `decision_log`；**不调用** `paper_trade` / `live_trade`；默认 `--dry-run`。
- **只读下层数据**：指标用 SQLite `mode=ro` 读 `token_indicators`；可选读 `pairs.raw_json` 快照。**不写** tokens / pairs / pair_history / token_indicators。
- **策略插件化**：每个策略一个文件，注册进 `STRATEGY_REGISTRY`；加策略不改引擎核心。
- **入场风控**：`RiskManager` 对 buy 做流动性地板（`DECISION_MIN_LIQ_USD`，默认 50000）和可选冷却（`DECISION_COOLDOWN_SEC`，代码默认 0）。未通过的 buy 在写入 `decision_log` 前丢弃。卖出不过滤。不改 JEV 强度默认、权重或 purpose。对照表见 `DECISION_ENGINE_FILTER_PARITY.md`。
- **零侵入**：不改 indicators / 爬虫主循环 / 权重 / hooks；不订 `INDICATORS_ON_UPDATE_HOOK`；不打印密钥（含 `API_SECRET` / `JEV_API_Key` 等）。

## 新增文件

```
decision_engine/
  __init__.py              # 版本 0.1.0-step1
  config.py                # DECISION_* 环境变量 + 项目 DB_PATH
  run.py                   # CLI：--strategy / --all / --dry-run / --once / --ticks
  core/
    engine.py              # 主循环：读数 → 策略 → 风控 → 信号总线
    data_adapter.py        # 只读 token_indicators；可选 get_pair_snapshot
    risk_manager.py        # 买入流动性地板 + 可选冷却
    signal_bus.py          # 标准化信号 + decision_log 写入
  strategies/
    __init__.py            # STRATEGY_REGISTRY
    base_strategy.py       # on_tick / buy / sell
    jev_strategy.py        # jev_strength_v1
  adapters/
    dry_adapter.py         # 空跑适配器（不接执行）
DECISION_ENGINE_STEP1.md
DECISION_ENGINE_STEP1_RESULT.md
```

**对主链路的改动**：**无**。未改 `config.py` 默认开关、`store.py`、`main.py`、`indicators/`、`auto_hooks.py`、`paper_trade.py`、`live_trade.py`。

## 与上下游对接

### 输入（只读）

| 来源 | 用法 |
|------|------|
| `token_indicators` | 主输入；PK `(chain_id, token_address)`；`list_hot_tokens` 优先 `tier='hot'`，按 `jev_strength` 降序 |
| `pairs` | 可选 `get_pair_snapshot`（`priceUsd` / `liquidity.usd`）；Step 1 策略未调用 |
| API `127.0.0.1:8080` | 可选后备（`DECISION_USE_API_FALLBACK`，默认关）；Step 1 优先 SQLite |

关键字段：`change_5m/15m/1h/4h/24h`、`volatility_24h`、`volume_strength`、`jev_*`、`tier`、`primary_pair_address`、`updated_at`。

### 输出（仅日志 / 表）

| 输出 | 说明 |
|------|------|
| 结构化日志 | `SIGNAL strategy=… action=…` |
| `decision_log` | 新建表；独立 RW 连接写入（与指标 RO 连接分离） |

**不接**：`paper_trade.py`、`live_trade.py`、`auto_hooks`。

## `decision_log` 表

首次 emit / 启动 SignalBus 时 `CREATE IF NOT EXISTS`：

| 列 | 类型 | 说明 |
|----|------|------|
| `id` | INTEGER PK | 自增 |
| `ts` | TEXT | UTC ISO |
| `strategy_id` | TEXT | 如 `jev_strength_v1` |
| `action` | TEXT | `buy` / `sell` |
| `chain_id` / `token_address` | TEXT | 标的 |
| `size_pct` | REAL | 仓位占比 |
| `reason` | TEXT | 触发原因 |
| `risk_passed` | INTEGER | 写入的行是通过风控的（1）。`no_liquidity` / `liq_below_min` / cooldown 未通过的 buy 在 emit 前丢弃，不落行 |
| `mode` | TEXT | `dry_run` / `live_stub` |
| `raw_json` | TEXT | 完整信号 JSON |

## 策略 `jev_strength_v1`

| 参数 | 默认 | CLI / env |
|------|------|-----------|
| `min_jev_strength` | `0.3` | `--min-jev-strength` / `DECISION_JEV_MIN_STRENGTH` |
| `position_pct` | `0.05` | `--position-pct` / `DECISION_JEV_POSITION_PCT` |

逻辑：扫描 `list_hot_tokens(limit)`；若 `jev_strength >= min` 则 `buy`（附 `primary_pair_address`、`jev_signal`、`jev_score`）。

## 厚池仓位（thick pool）

纸面执行可以按满额名义成交。决策层不因此把旧买入一律写成 `size_pct=1`。

买入 `size_pct`：

- **约 1.0** 仅当四条同时成立：`liq_usd ≥ 150000`、池龄 `≥ 7` 天、R3=0、`jev_strength ≥ 0.15` 且流动性有测量。R3 与指标旁路同一条：`volatility_24h > 2.5` 且（`change_1h < 0` 或 `rsi_14 < 30` 或 `rsi_14 ≥ 70`）则为 R3=1，不满仓。
- **其余买入** 保持现有地板 `size_pct=0.05`（显式更小的 `position_pct` 保留）。不抬到 0.25。
- 入场地板不动：live 流动性 `≥ 50k`、策略强度阈值、回测 `coverage ≥ 10`。本规则只选仓位，不另开一道拒单。
- 可选、默认不挡：`DECISION_THICK_STRICT_MIN_LIQ_USD=500000` 才把满仓流动性抬到 50 万。`supply_gaps` 未闭合窗口不在本层跳过买入。
- 不改 live 开关、执行层 `PAPER_SIZE_MULT`、指标权重，也不读、不关 #71 `step2_blocked`。

## 配置（`decision_engine/config.py` / 环境变量）

| 变量 | 默认 | 含义 |
|------|------|------|
| `DECISION_DB_PATH` / `DB_PATH` | 项目 `DB_PATH` / `dexscreener.db` | SQLite 路径（两者都认；启动日志打绝对路径） |
| `DECISION_TICK_INTERVAL_SEC` | `60` | 循环间隔 |
| `DECISION_HOT_TOKEN_LIMIT` | `50` | hot 扫描上限 |
| `DECISION_DEFAULT_STRATEGY` | `jev_strength_v1` | 默认策略 |
| `DECISION_JEV_MIN_STRENGTH` | `0.3` | JEV 阈值 |
| `DECISION_JEV_POSITION_PCT` | `0.05` | 策略默认 `position_pct`。普通买入再被 `DECISION_ORDINARY_SIZE_PCT`（0.05）封顶 |
| `DECISION_ORDINARY_SIZE_PCT` | `0.05` | 普通买入仓位上限。不抬到 0.25 |
| `DECISION_THICK_POOL_SIZE_PCT` | `1.0` | 厚池满仓 `size_pct`。四条不齐则用不到 |
| `DECISION_THICK_MIN_LIQ_USD` | `150000` | 厚池流动性。缺测量不算过 |
| `DECISION_THICK_MIN_POOL_AGE_DAYS` | `7` | 厚池池龄（天） |
| `DECISION_THICK_R3_VOL_THR` / `DECISION_THICK_R3_RSI_LO` / `DECISION_THICK_R3_RSI_HI` | `2.5` / `30` / `70` | R3 冻结阈值，与 `shadow_stop_prone.eval_r3` 对齐 |
| `DECISION_THICK_MIN_JEV_STRENGTH` | `0.15` | 厚池才要求的强度。不替代策略自己的入场阈值 |
| `DECISION_THICK_STRICT_MIN_LIQ_USD` | 未设 | 可选更严档。设 `500000` 才要求 50 万。不读 `supply_gaps` |
| `DECISION_COOLDOWN_SEC` | `0` | 同一 `(strategy, chain, token)` 买入冷却秒数。代码默认 `0` = 关闭。临时 paper 观察在进程环境里设 `3600`，与回测 / paper 的 `max_hold_min=60`、`time_exit` 默认 `max_hold_seconds=3600` 对齐。不要把代码默认改成 3600。重启配方见 `DECISION_ENGINE_DRYRUN_24H.md`。冷却状态在进程内，重启清零 |
| `DECISION_MIN_LIQ_USD` | `50000` | 实盘/dry-run 买入流动性下限（USD），与回测 `FilterConfig.min_liq=50000` 对齐。`liquidity_usd` 缺失（`no_liquidity`）或低于下限（`liq_below_min`）的 buy 在写入 `decision_log` 前丢弃。卖出不过滤。只做风险入场过滤，不改变 JEV 强度阈值、权重或 purpose |
| `DECISION_USE_API_FALLBACK` | `0` | 是否走 API（Step 1 默认关） |

## 如何运行

仓库根 `/workspace/dexscreener-crawler`：

```bash
# 单次验证（推荐）
.venv/bin/python -m decision_engine.run --strategy jev_strength_v1 --dry-run --once

# 跑 N tick
.venv/bin/python -m decision_engine.run --strategy jev_strength_v1 --dry-run --ticks 3 --interval 2

# 调低阈值以便看到信号（库内 max jev_strength 可能 < 0.3）。
# 低于默认 0.3 且不传 --purpose 时，purpose 写成 sample，不是 paper 候选。
.venv/bin/python -m decision_engine.run --strategy jev_strength_v1 --dry-run --once --min-jev-strength 0.15

# 持续循环（Ctrl+C 退出）
.venv/bin/python -m decision_engine.run --strategy jev_strength_v1 --dry-run --interval 60
```

与主爬虫 / 指标进程并行即可；**不要**杀 stabilize 的 `main.py --loop`，**不要**删 `LIVE_TRADING_DISABLED`。

## 验证标准（Step 1 通过条件）

1. `--once` → **退出码 0**
2. 日志含：读库 / tick / 信号或「无信号」
3. `decision_log` 表存在；有信号则有行
4. 指标层与采集层代码 / 默认开关未改动

## 验证结果（摘要）

详见 `DECISION_ENGINE_STEP1_RESULT.md`。

| 时间 | 命令 | 结果 |
|------|------|------|
| 2026-10-10 ~04:27 HKT | `--once` 默认阈值 0.3 | exit 0；indicators≈1507；hot=50；信号 0；max jev≈0.205 |
| 2026-10-10 ~04:27 HKT | `--once --min-jev-strength 0.15` | 14 条 buy 写入 `decision_log` |
| 2026-10-10 13:06 HKT | `--once` 默认阈值 0.3 | exit 0；indicators=**5782**；hot=50；信号 0；max jev=0.205 |

默认阈值下「无信号」属预期（强度未达 0.3），不是故障。

## Backtest ↔ live filter parity

清单在 `DECISION_ENGINE_FILTER_PARITY.md`。`min_liq=50000` 已由 live `RiskManager` 执行（PR #41，日志 `min_liq_usd=` / `reason=liq_below_min` / `reason=no_liquidity`）。`min_price=1e-6`、`min_coverage=10`、以及周检对 coverage 缺失的 fail-closed，live 都还没执行。不要在本步笔记里新造阈值。

## 后续（非本 Step）

- Step 2：历史回测框架 + 对接 `pair_history` / `paper_trade` 账本
- Step 3：多策略并行 + 实时模拟盘
- Step 4：小额实盘灰度（须过五层闸门）
- 事件 hook 订阅、API 写路径 — 均非 Step 1。买入流动性地板是之后的 PR #41，见 `DECISION_ENGINE_FILTER_PARITY.md`
