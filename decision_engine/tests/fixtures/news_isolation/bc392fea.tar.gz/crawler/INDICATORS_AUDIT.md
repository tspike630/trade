# Indicators 加工层全流程审计（INDICATORS_AUDIT）

> 审计时间：2026-10-10（HKT）  
> 范围：indicator layer + 已有只读消费者。**不启用** scoring/alert 加权（`INDICATORS_WEIGHT_*=0`）。  
> **未停止** `main.py` / `indicators.run` / `sources.jev`；仅在需要时安全重启 `api_server`。

## 清单总览

| # | 项 | 状态 | 说明 |
|---|----|------|------|
| 1 | indicators package：technical / funding / sentiment / composite | **DONE** | tech/funding/sentiment 已实现；composite 原 stub → 本次补骨架（权重 0 时 no-op） |
| 2 | 表 `token_indicators` + `indicator_history` + `jev_signals` | **DONE** | 实库均存在；schema 由 `models/indicator_tables.sql` + migrate |
| 3 | 运行循环：`indicators --loop`、`sources.jev --loop`、stabilize main | **DONE** | 三进程在跑；daily_check 巡检 |
| 4 | API `/indicators` + `/top` + auth | **DONE** | 鉴权 `X-API-Key`；响应补齐 sentiment/composite 块 |
| 5 | grok_dd technical / funding / sentiment | **DONE** | `scripts/grok_dd_report.py` 三节齐全 |
| 6 | daily_check indicator / JEV / proc | **DONE** | 原有三进程+JEV+新鲜度；本次加 history / sentiment 覆盖 |
| 7 | `top.sh`、`--telegram` DD、admin Top board | **DONE** | `./top.sh`、DD `--telegram`、`static/admin.html` Indicators Top |
| 8 | AUTH_JEV / public mode（无错 key） | **DONE** | 见 `AUTH_JEV.md`；空 key=公开；改 key 只重启 jev |
| 9 | composite stub？hot history？on_indicator 门控？ | **DONE** | composite 骨架+权重 0；hot 已写 history；`INDICATORS_ON_UPDATE_HOOK` 默认关 |
| 10 | README / docs 索引 | **DONE** | README 增 Indicators 节 + 命令表链到本文 |

图例：DONE = 已完备；PARTIAL = 部分；MISSING = 缺失（审计后已补的标 DONE 并在「本次修复」列出）。

---

## 逐项详情

### 1. indicators package

| 模块 | 状态 | 备注 |
|------|------|------|
| `indicators/technical.py` | DONE | 分档 change / volatility / volume_strength；hot 写 history |
| `indicators/funding.py` | DONE | 只读 `jev_signals`；映射 `jev_*` |
| `indicators/sentiment.py` | DONE | 只读 `x_watch` + social alerts |
| `indicators/composite.py` | DONE（原 PARTIAL） | 加权合成骨架；`sum(weights)==0` 时整批跳过 |
| `indicators/base.py` | DONE | schema ensure、upsert、top 白名单 |
| `indicators/run.py` | DONE | `--full` / `--once` / `--loop`；tech→fund→sent→composite |

### 2. 表

- `token_indicators`：技术 + JEV + sentiment + composite 列（含 migrate）
- `indicator_history`：hot 归档（含 `jev_strength` / sentiment 快照列）
- `jev_signals`：由 `sources.jev` 写入，indicators funding 只读

### 3. 运行循环

```bash
# 当前期望（stabilize）
python main.py --helius-listen --sources x --loop --interval 60
python -m indicators.run --loop --interval 300
python -m sources.jev --loop --interval 900
python -m api_server   # 只读 API + admin
```

勿在改 JEV key / indicators 代码热修时停 main；api 变更可单独重启 api_server。

### 4. API

- `GET /indicators/top?chain=&sort=&limit=` — sort ∈ `change_5m|jev_strength|volume_strength`
- `GET /indicators/{chain}/{token_address}`
- 鉴权：与其它数据路由相同（`API_SECRET` → `X-API-Key`；`/health` 开放）
- 响应块：`technical` / `funding` / `sentiment` / `composite` + meta

### 5. grok_dd

`assemble_token_context` 拉取 `token_indicators`；markdown 含：

- 技术面 Technical
- 资金面 Funding (JEV)（可回落 `jev_signals`）
- 舆情面 Sentiment（无则「暂无数据」）

### 6. daily_check

`check_indicators_p0`：

- 三进程可见性（WARN 非 FAIL）
- `jev_signals` 覆盖
- `token_indicators` 新鲜度
- **新增** `indicator_history` 行数
- **新增** sentiment 填充计数

### 7. UX 只读消费者

| 工具 | 用法 |
|------|------|
| `./top.sh jev\|change5m\|volume [chain] [limit]` | 调 `/indicators/top` |
| `python scripts/grok_dd_report.py … --telegram` | 可选推 admin 频道 |
| Admin `/` → Indicators Top | 前端 `fetch` |

### 8. AUTH_JEV

- 未设 `JEV_API_KEY` → 公开扫描（与旧行为一致）
- 设 key 后按 `JEV_AUTH_MODE=header|bearer|query` 附加；日志脱敏
- **只重启** `sources.jev`，不停 main/indicators  
  详见 **AUTH_JEV.md**

### 9. Composite / history / hooks

| 项 | 行为 |
|----|------|
| `INDICATORS_WEIGHT_TECHNICAL/FUNDING/SENTIMENT` | **默认全 0** → composite no-op，不进 scoring/alerts |
| Hot history | technical / funding / sentiment（及未来 composite）在 hot 时 `insert_indicator_history` |
| `INDICATORS_ON_UPDATE_HOOK` | 默认 `0`；`auto_hooks.maybe_on_indicator` 门控 |
| `JEV_ON_NEW_LISTING` | 默认关；`auto_hooks.note_new_listing_for_jev`（已修缺失 import） |

### 10. 文档索引

- 本文 **INDICATORS_AUDIT.md**（运维入口；含「警示事例 → 指标层纪律」）
- STEP1 / STEP2 / STEP3 / P0 / LIGHT / AUTH_JEV（P-4 定价错误在 STEP2）
- **INDICATORS_FACTOR_CANDIDATES.md** — 机构供需 P-3 / P-4；艾略特 E-1 / E-4 / E-5 与拒绝项 N-1..N-6（指针见本文「艾略特候选」）；江恩 G-5 换手率 A 类候选，G-7 / G-8 仅登记并阻断，江恩 N-1..N-6 另表拒绝（指针见本文「江恩候选」）；I-2 持币集中度候选的 I-1 数据阻断已解除（指针见本文「持币集中度」）。**M-2** 周跑只在 IC 有限时把双侧结果写入既有观察 jsonl，`gate_candidate` 仍不改 `accepted`。本次不新增观察 jsonl。权重 0，不算有效性
- **INDICATORS_OPERATORIZATION.md** — **M-3** 时间序列算子硬规则（窗口在 t 收口；禁止日合计 / 未来分母）
- 本文「统计功效脚注（M-1）」— n≥15 不改；约 350 个已结算样本才够谈 α≈0.02
- README「Indicators 旁路」节 + 命令总索引

---

## 本次修复（safe）

1. **`indicators/composite.py`**：实现加权合成骨架；权重全 0 时 `run_batch` 直接返回、不写库。
2. **`config.py`**：`INDICATORS_WEIGHT_*` 默认改为 `0`；新增 `INDICATORS_ON_UPDATE_HOOK=0`。
3. **`api_server.py`**：`_format_indicator_row` 补 `sentiment` + `composite`（及 `jev_funding_bias`）。
4. **`indicators/run.py`**：funding 尊重 `INDICATORS_WRITE_HISTORY_HOT`；composite 打日志；可选 hook 门控调用。
5. **`auto_hooks.py`**：补 `JEV_ON_NEW_LISTING` / `JEV_PENDING_PATH` import（原 NameError 被 pipeline 吞掉导致队列永无效）；加 `maybe_on_indicator`。
6. **`daily_check.py`**：`indicator_history` + sentiment 覆盖检查。
7. **`demo_indicators_p0.py`**：断言 API shape / DD 舆情节 / composite weight-0 no-op。
8. **README / env.example / deploy env**：Indicators 运维索引与权重说明。
9. **本文档**。

**未做（按范围）**：未改 `scoring.py` / 告警阈值；未把 composite 权重大于 0；未停 main/indicators/jev。

---

## 警示事例 → 指标层纪律

> 来源：执行单《预测市场经验落地执行单（Polymarket 指南 → 系统改进）》（2026-10-14）第四节警示案例，以及同单 P-2 / P-5。看板平仓旁证已在 PR #45。本节是指标 / 旁路层纪律，**不算策略有效性**。IC/IR 与统计参仍归 **10-19 周检**。不改 `INDICATORS_WEIGHT_*`、composite 默认、technical loop。

- **半胜仍亏 / 单笔抹盈**（书中约 51% 胜率仍大亏；本系统 paper 上单笔亦可抹掉全部盈利）：指标侧**不**用强信号当确定性。**信号强度 ≠ 胜率**（口径见 `INDICATORS_STEP2.md` P-4）。`INDICATORS_WEIGHT_*` 保持 **0**，直至 10-19 IC/IR + R3；不盘中追认统计参。
- **$0.95 黑天鹅 / 薄池打穿**（「那 5% 一旦出现，亏掉的不是 5% 而是 95%」；薄池单笔止损打穿、抹掉全部盈利）：tech 新鲜度与流动性字段是决策闸的输入。指标**不编造** liquidity（载荷缺 `liquidity` 就保持空）。`min_liq` fail-closed 归决策 [#41](https://github.com/tspike630/trade/pull/41)。本侧只保 hot tech 新鲜（[#40](https://github.com/tspike630/trade/pull/40) 已合）。
- **洗盘 / 单点操纵**（书中约 25% 交易量虚假，外加预言机投票权集中翻转）：多源旁路（DexScreener + CCXT prior，见 `CCXT_SIDECHANNEL.md`）是防单点，不是加权重救曲线。
- **因子质量 > 研究量**（Prediction Arena, arXiv 2604.07355）：纪律段在 `INDICATORS_FACTOR_CANDIDATES.md`。
- **ALPHA_DECAY（2026-10-16，只观察）**：衰减两因是过拟合假因子与拥挤，只登记衰减风险。不写实锤，也不下「JEV 已被证伪」这类证伪判决。factor_loop 三门槛（新颖性 / 假设对齐 / 复杂度）对接已有 M-2 / M-3，不另开 LLM 挖因子闭环。半胜仍亏主因归 #72 退出质量，不与衰减混成一个故事。先做 M-A6 式滚动 IC / 衰减斜率（M-A5 / M-A6 均为设计候选 / 先决观察），再扩收候选。`INDICATORS_WEIGHT_*` 保持 **0**。全文见 `INDICATORS_FACTOR_CANDIDATES.md`「ALPHA_DECAY 学习批判」。
- **方向与算子（M-2 / M-3）**：factor_loop 候选先做正反方向校准（`INDICATORS_FACTOR_CANDIDATES.md`）；时间序列只许用到当前 bar（`INDICATORS_OPERATORIZATION.md`）。两条都不把信号强度当成胜率（口径仍是上面的 **信号强度 ≠ 胜率**，`INDICATORS_STEP2.md` P-4，PR #46）。

### P-2（指针，不实现）

`review.factor_loop` 按因子 IC/IR 动态加权是 **design-after-10-19**：10-19 真库 IC/IR 出数之后才写设计稿（公式与阈值）。在此之前权重保持 0，不激活，不过门槛不生效。本文不实现权重更新代码。

### P-5（观察候选）

Polymarket 共识概率（例如「某币是否上币安」，价格 = 市场共识）只作为 factor_loop 的**观察因子候选**，须走验证流程，**不接入主决策**。书中警告：加密相关市场胜率约 60%，约 25% 交易量是洗盘，且有合规风险（中国大陆非法 / 香港灰色）；接入前先做合规评估。当前未接线。

### 统计功效脚注（M-1，观察口径）

Foresight Arena（arXiv 2605.00420）要检测相对市场共识 α≈0.02 的 edge，大约需要 **350** 个已结算预测。指标 / JEV 读样本时仍用周检门槛 **n≥15**（unique≥10）；W41 快照 n≈32 只说明方向，不够声称已经证明 edge。门槛不改。看板同一句旁证在 PR #53。本段不算有效性。信号强度仍 ≠ 胜率（`INDICATORS_STEP2.md` P-4）。

### 算子化（M-3，指针）

指标和因子的时间序列代码只许使用截止当前 bar 的数据，滚动窗口在 t 收口，禁止日合计或未来分母。全文硬规则在 `INDICATORS_OPERATORIZATION.md`。这不是新的打分，权重保持 0。

### 艾略特候选（指针）

E-1（`fib_retrace_0618` / `fib_retrace_05` / `fib_retrace_0382`）、E-4、E-5 与拒绝项 N-1..N-6 登记在 `INDICATORS_FACTOR_CANDIDATES.md`。E-1 是 A 类 factor_loop 候选，依赖尚未实现的波段原语（N 根 K 线局部极值对，OHLC）；正反方向走 `calibrate_direction`（M-2），时间序列走 `INDICATORS_OPERATORIZATION.md`（M-3），回测含滑点 / 成本。E-4 只在同价位多因子命中相对单因子有 up_1h 增益时保留。E-5 是量能斜率 / 背离观察，`pair_history` 已有 volume，不是新因子。E-3：因子只辅助确认，决策与 PM 硬规则拥有下单。meme / 新币若 up_1h 无增益，E-1 退役，不恋战。10-19 之后且校准与算子化完成才谈 A 类。E-2 归执行，不在指标层。权重 0。不算有效性。不写看板代码。不实现 Elliott 检测器。

### 江恩候选（指针）

G-5（`turnover_spike_v0` / `turnover_exhaust_v0`，G-15 同族不另给 id）仍是 A 类 factor_loop **候选**。公式是同一历史行的 `volume_h24 / market_cap`（备选同一行 `/ fdv`；#70），对齐 JEV `up_1h`，周检门槛仍是 n≥15 / unique≥10 / 1h≥55%。禁止拿 `pairs` 最新市值去配更早的 `volume_h24`。周检计数要等 10-19 且 M-2、M-3 完成；分母列不再是阻断。周检必须用同一行非 NULL 的 `market_cap`（或 `fdv`）；NULL 分母行跳过；覆盖率只作 10-19 观察，不算有效性。`tokens` 仍无市值列。检测器仍不实现，不进 `decision_engine`，不 INSERT `factor_candidates.db`，不新增观察 jsonl，`gate_candidate` / `accepted` 不改。G-7 `breakout_second` 阻断到链上突破定义写死（N 根新高 vs 历史池，防 look-ahead，与 E-1 波段原语同一 TODO）。G-8 `rel_strength` 阻断到市场基准写死（池均值 vs BTC）。江恩 N-1..N-6（案例、做空、人工画线、日历、时间预言、期货）另表拒绝，与艾略特 N 表不是同一组。权重 0。不算有效性。

### 持币集中度（I-2，指针）

I-2（`concentration_top10` 横截面风险、`concentration_delta` 为 top10 占比的 24h 变化）登记在 `INDICATORS_FACTOR_CANDIDATES.md`，是 factor_loop 候选。**I-1 数据阻断已解除**：采集层 #79 写入 `address_labels`、`token_holder_snapshots`、`token_transfer_edges`；`indicators/holder_metrics.py` 只读计算 `top10_share`（单次快照，`top10_share_history` 留给 24h 变化）和 `dev_balance_delta`（`dev` 标签上的净流量；没有可用转账边时才用重复出现的持仓余额）。空输入与算不出的行为 NULL，不编造持仓。`concentration_top10` / `concentration_delta` 可以读这条 `top10_share` 历史；历史还没覆盖到窗口时变化仍是 NULL。可选 `hhi_index` 只作日后与 top10 二选一的备选。M-2 正反两符号；双门槛仍是 n≥15 / unique≥10 / 1h≥55%。A 类周检仍要 **10-19 + M-2 + M-3**。权重 0。无检测器，不进 `decision_engine`，不进 composite，不 INSERT `factor_candidates.db`，不改 `gate_candidate` / `accepted`，不新增观察 jsonl。过门槛不自动激活。INTEL_LOOP：周检可以跑缺口扫描模板；AI 候选 ≠ 自动生效（R2/R3），无新自动化。I-3 / I-4 归执行 / registry，不在指标层。不算有效性。

### 学习 → 改可观测（2026-10-14）

今日 paper 回撤是 stop_loss 连击加上 daily_loss 触发，不是技术面断供。教训：继续证明 hot tech 新鲜，回撤途中不改权重。进步和看板一样，是把旁证做成可导出，而不是改门槛。

- M-2 只观察：周跑在候选带有有限 IC 时调用 `calibrate_direction`，把正反两符号追加到 `exports/reports/direction_calibration_observe.jsonl`。`gate_candidate` 仍不据此改 `accepted`。`DIRECTION_CALIBRATION_TODO` 保留。权重保持 0。
- 新鲜度旁证：`python -m indicators.freshness_report` 只读 `token_indicators.tech_updated_at`，写出 `exports/reports/indicators_freshness_YYYYMMDD.md`（分档 ≤10 分钟计数、hot 年龄 p50/p90、可选 loop PID）。供流正常 ≠ 下游能用。
- 不做：Elliott 检测器（E-1 / E-4 / E-5 仍只登记，见上节）、盘中改参。`INDICATORS_WEIGHT_*` 仍为 0。本段不算有效性。

---

## 运维速查

```bash
cd /workspace/dexscreener-crawler
source .venv/bin/activate

# 状态
pgrep -af 'main.py|indicators.run|sources.jev|api_server'
python daily_check.py

# 指标单次 / 全量
python -m indicators.run --once
python -m indicators.run --full          # 显式全量，无视 INDICATORS_ENABLED=0

# Top
./top.sh jev
./top.sh change5m solana 20

# API（密钥勿回显到日志）
curl -sS -H "X-API-Key: $API_SECRET" \
  "http://127.0.0.1:8080/indicators/top?chain=solana&sort=jev_strength&limit=5"

# 冒烟
python demo_indicators_p0.py

# 改 JEV key 后（只重启 jev）
pkill -f 'python -m sources.jev' || true
nohup .venv/bin/python -m sources.jev --loop --interval 900 >> logs/jev.log 2>&1 &

# 仅重启 API（指标响应格式变更后）
pkill -f 'python -m api_server' || true
nohup .venv/bin/python -m api_server >> logs/api_server.log 2>&1 &
```

### 环境变量（指标相关）

| 变量 | 默认 | 含义 |
|------|------|------|
| `INDICATORS_ENABLED` | `1` | loop/once 总开关（`--full` 仍可跑） |
| `INDICATORS_HOT/WARM/COLD_INTERVAL_SEC` | 300/1800/14400 | 分档刷新 |
| `INDICATORS_WRITE_HISTORY_HOT` | `1` | hot 写 `indicator_history` |
| `INDICATORS_WEIGHT_*` | `0` | composite 权重（全 0=关闭） |
| `INDICATORS_ON_UPDATE_HOOK` | `0` | 加工后 hook |
| `SENTIMENT_ENABLED` | `1` | 舆情加工 |
| `JEV_API_KEY` / `JEV_AUTH_MODE` | 空 / `header` | 见 AUTH_JEV.md |

---

## 验收建议

1. `python demo_indicators_p0.py` → `DRY_RUN_OK`
2. `python daily_check.py` → Indicators 相关无 FAIL
3. `./top.sh volume` → HTTP 200 + JSON items
4. 确认 `INDICATORS_WEIGHT_*=0` 且 `token_indicators.composite_score` 不因 loop 被批量写入
