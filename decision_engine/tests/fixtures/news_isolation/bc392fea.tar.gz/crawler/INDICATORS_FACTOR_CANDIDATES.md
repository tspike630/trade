# Indicators · factor_loop 候选登记（P-3 / P-4 · E-1 / E-4 / E-5 · G-5 · I-2）

> 日期：2026-10-14  
> 来源：机构供需交易法执行单（Sam Seiden / LTSD 改编）的 **P-3、P-4**；艾略特波浪执行单（Frost & Prechter，《艾略特波浪理论》20 周年纪念版）的 **E-1、E-4、E-5**；江恩《Truth of the Stock Tape》（1923，中译《江恩趋势理论》）落地执行单的 **G-5**（G-15 同族）以及带阻断的 **G-7 / G-8**；对手盘情报执行单 + INTEL_LOOP 的 **I-2**（持币集中度；I-1 数据阻断已解除，见下）。指标旁路只领这些。P-1（推保护）、P-2（概率打分 / 动态仓位）、**E-2**（`target_band_failover`，目标位失效切换，归执行 / PM）与江恩其余纪律项（G-1..G-4、G-6、G-9..G-14）不在本文。**I-3 / I-4** 归执行 / registry，不在指标层。  
> 状态：**文档候选**。未接入决策，未改权重，**不算有效性**。

本文登记供需两条假设，艾略特回撤候选、交汇方法与量能观察，江恩换手率候选，以及 I-2 持币集中度候选。I-1 的数据阻断已解除：采集层 [#79](https://github.com/tspike630/trade/pull/79) 已有 `address_labels`、`token_holder_snapshots`、`token_transfer_edges`，指标侧只读公式在 `indicators/holder_metrics.py`。不新增因子模块，不改 `decision_engine`、`review/factor_layers.py`，不写 `review/factor_candidates.db`。本次不新写采集器，不改 holder 快照的写入。`gate_candidate` 的接受路径不改；M-2 的 `calibrate_direction` 还没接到周跑（见下文）。`INDICATORS_WEIGHT_*` 保持 **0**。本次不新增观察 jsonl。

检测器本次不实现。2026-10-19 周检之后，并且方向校准（M-2）与算子化（M-3）都完成后，才走 **A 类**验证（回测依据 + 变更登记 + 周检验证，纪律同 R1/R2/R3）。验证前这些条目不是信号、不是仓位、不是止损规则。

与 `INDICATORS_STEP2.md` 的 P-4（JEV 信号强度 ≠ 胜率）不是同一条。方向校准（下文 M-2）只决定符号，不把 `|IC|` 或 `jev_strength` 读成胜率。

时间序列检测器一旦要写，遵守 `INDICATORS_OPERATORIZATION.md`（M-3）：窗口在 t 收口，禁止日合计 / 未来分母。

**纪律（Prediction Arena，[arXiv:2604.07355](https://arxiv.org/abs/2604.07355)）**：研究量 / token 用量与 PnL 相关约 0，因子质量高于研究量。指标侧不为凑候选条数再堆因子，只加深已有口径（JEV 纯化、流动性闸、僵尸过滤）。供需 P-3 / P-4 保持 A 类候选。艾略特只追加执行单点名的 E-1 三个回撤水平（同一假设）与依赖它的 E-4 / E-5；艾略特 N-1..N-6 明确不追加。江恩只追加执行单点名的 G-5 换手率一族（两个标签，同一族；G-15 不另给 id）。G-7 / G-8 只登记并写明阻断，不实现检测器。江恩 N-1..N-6 是另一张拒绝表（见文末），与艾略特 N 表不是同一组内容。对手盘只追加执行单点名的 I-2 两个集中度标签（横截面与 24h 变化，同一假设）；`hhi_index` 只作日后与 top10 二选一的备选，不另堆一条。I-1 的 `dev_balance_delta` / `top10_share` 已是只读公式，数据阻断已解除，仍不入库、不改权重。I-3 / I-4 不追加。INTEL_LOOP 只留周检缺口扫描的一句纪律（AI 候选 ≠ 自动生效），不写自动化。该文 P-1 首次命中率归复盘 / 周检，指标侧不登记。本段不算有效性。

**ALPHA_DECAY 学习批判（2026-10-16，只观察）**：只登记候选、不把文献读成纪律，衰减会被写成另一套因子。本段是读后的纪律，不是新候选，**不算有效性**。衰减两因：过拟合 / p-hacking 造出的假因子，以及因子变拥挤之后失效。这里只登记**衰减风险**。不写实锤，也不下证伪判决。「JEV 已被证伪」这种说法过重，本文不采用。

[AlphaAgent](https://arxiv.org/abs/2502.16789)（arXiv:2502.16789，KDD 2025）用三道正则压衰减：相对 alpha zoo 的 AST 新颖性、假设与因子对齐、复杂度（符号长度 SL / 参数个数 PC）。factor_loop 把这三道收成已有纪律，对接 M-2（`calibrate_direction`，正反符号）与 M-3（窗口在 t 收口），不另开一条 LLM 挖因子再下单的闭环。新候选先对照本文已登记的库，近重复不另开 id；表达式要对得上书面假设，符号仍走 M-2；过复杂的式子不靠堆算子过关，窗口仍走 M-3。决策层对同一篇的准入读法在 `DECISION_ENGINE_RESEARCH_MAPPING.md`。本文不改那一侧的门槛，不改 `JEV_MIN_STRENGTH`，不改 #78。

域外警告：该文战场是 CSI500 / S&P500 的**日频 OHLCV**，不是 Solana meme 的 5 秒 tick。日频股票上的结论不能改写成链上因子的判决。#71 / #72 是 Step2 的硬旁证（止损占亏、日开仓），与学术论文里的因子判决不是同一件事。半胜仍亏的主因归 **#72 退出质量**，不与因子衰减混成一个故事。

链上表面量价可以被合成。[操纵型 meme 机器人](https://arxiv.org/abs/2601.08641)（arXiv:2601.08641，WWW 2026）讨论 bundle / sniper / bump / comment 启发式，以及对跟单者的 bonding-curve 模仿惩罚。本文不实现这些检测器，也不把惩罚接进执行。本侧 I-1 的 `holder_metrics`（#80）仍是只读公式；I-2 仍等 M-2 / M-3；`bot_trade_share` 稀疏。替代数据这条护城河还不完整。CryptoCompass（2026-06）记到 Solana AI 钱包约占 memecoin DEX 成交量的 34%；同一数据源会同步进出，表面成交量与持仓可以是合成的。防御性提示是 top20 代理份额 >40%，只作提示，不当门槛、不改权重。在这种健康度被观察到之前，再堆 G-5 / E-1 一类浅层量价，就是 p-hacking 风险。已登记的 G-5 / E-1 保持候选、权重 0，不因此升级，也不因此再拆新 id。

**先做 M-A6 式滚动 IC / 衰减斜率观察，再扩收候选。** M-A5 与 M-A6 都只是**设计候选 / 先决观察**，不写入下文登记表，不实现，不新增观察 jsonl，不改 `gate_candidate`。M-A1..A6 一律不另开表行、不暗示接线。M-A6 指对已有口径看滚动 IC 与衰减斜率；这步没做之前不扩收新候选。`INDICATORS_WEIGHT_*` 保持 **0**。本段不算有效性。

---

## 登记

| ID | 名称 | 级别 | 接线 |
|----|------|------|------|
| P-3 | 吸筹区回踩 `accum_zone_retest` | A 类 factor_loop **候选** | 无。权重 0 |
| P-4 | 新鲜度衰减 `zone_freshness_decay` | 与 P-3 一并登记的 A 类 **候选** | 无。权重 0 |
| E-1 | 斐波那契回撤 `fib_retrace_0618` / `fib_retrace_05` / `fib_retrace_0382` | A 类 factor_loop **候选** | 无。权重 0。依赖波段原语（TODO，未实现） |
| E-4 | 同价位多因子交汇（hit-count） | 依赖 E-1 的方法学；**仅 up_1h 有增益才保留** | 无。权重 0。不单独入库 |
| E-5 | 量能斜率 / 背离 | **观察项**，还不是因子 | 无。等波段原语。`pair_history` 已有 volume |
| G-5 | 换手尖峰 `turnover_spike` | A 类 factor_loop **候选** | 无。权重 0。不实现检测器。分母自 #70 起在同一行 `pair_history.market_cap` / `fdv`（见下） |
| G-5 / G-15 | 换手枯竭 `turnover_exhaust` | 与尖峰同一族的 A 类 **候选** | 无。权重 0。不另开观察 jsonl |
| G-7 | 二次突破 `breakout_second` | **仅登记，阻断** | 无检测器。等链上突破定义（与 E-1 波段原语同一 TODO 姿态） |
| G-8 | 相对强度 `rel_strength` | **仅登记，阻断** | 无检测器。等市场基准（池均值 vs BTC） |
| I-2 | 持币集中度 `concentration_top10` | factor_loop **候选**。I-1 数据阻断已解除 | 无。权重 0。无检测器。可读 `top10_share`（`indicators/holder_metrics.py`） |
| I-2 | 集中度 24h 变化 `concentration_delta` | 与 top10 同一登记的 **候选** | 无。权重 0。不另开观察 jsonl。用 `top10_share` 历史，序列未覆盖则仍是 NULL |
| I-2 alt | `hhi_index` | **备选**。日后与 top10 二选一验证 | 无入库 `factor_id`。不实现 |
| I-1 | `dev_balance_delta` / `top10_share` | **只读公式**。数据阻断已解除 | `indicators/holder_metrics.py`。不进 decision / composite / factor_candidates。权重 0 |

建议日后入库的 `factor_id`（本文不 INSERT）：`accum_zone_retest_v0`、`zone_freshness_decay_v0`、`fib_retrace_0618`、`fib_retrace_05`、`fib_retrace_0382`、`turnover_spike_v0`、`turnover_exhaust_v0`。E-4 / E-5 不另给 `factor_id`。`breakout_second_v0` 与 `rel_strength_v0` 在阻断解开前不入库。`concentration_top10_v0` 与 `concentration_delta_v0` 仍不入库：I-1 数据阻断已解除，A 类仍要 10-19 周检、M-2 与 M-3，过门槛也不自动激活。`hhi_index` 验证前不入库。I-1 的 `dev_balance_delta` 不是 factor_loop 入库项。`status` 最高仍停在候选库的 `accepted` 语义；本登记甚至未落库。A 类验证排在 10-19 周检之后，且必须先过 `calibrate_direction`（M-2）与算子化（M-3）。

---

## P-3 吸筹区回踩

完全可算，阈值来自执行单，尚未当有效参数：

| 类别 | 定义 |
|------|------|
| 实体 | `\|open − close\|` |
| 振幅 | `high − low`。振幅 = 0 的 K 线不分类（既非静态也非动态） |
| 静态 K 线 | 实体 **<** 振幅的 50%：供求平衡、订单积累 |
| 动态 K 线 | 实体 **≥** 振幅的 50%：供求急剧失衡、订单消耗 |

形态（假设，不是现网规则）：

**入线（动态）→ 静态区间（连续静态 K 线）→ 出线（动态突破）→ 价格回踩该静态区。**

回踩静态区是执行单里的高盈亏比入场假设。区间上下沿一旦由连续静态 K 线定出，书中的克线 = 距现价最近的边界（入场挂单位），竭线 = 最远边界（止损放在竭线外）。这里只作几何标签：边界必须由上述 K 线规则算出。人工画区不采用（见下）。连续静态 K 线的最短根数执行单没有写死，留给 A 类验证，不在本文拍板。

**OHLC**：四价已在指标可及的数据里。`sources/ccxt` 的 `ccxt_ohlcv` 有 `open / high / low / close`；`indicators/technical_lib.compute_pandas_ta` 已接受 `high` / `low`。现网 technical 循环仍只读 `pair_history.price_usd`，缺省把 H/L 当成 close（见 `INDICATORS_PANDAS_TA.md`）。所以检测器不能直接套在现网 close 序列上。本次不写检测器，也不改 `technical_lib`。

方向：与 JEV 找便宜货同属低吸，和追涨相反。这只说明假设站在哪一边，不加 JEV 权重。

---

## P-4 新鲜度衰减

同一静态区上，**第一次回踩最有效；回踩次数 ≥ 2 之后衰减**。可量化：出线之后，价格再次进入该静态区，记一次回踩。

| 回踩次数 | 候选假设 |
|----------|----------|
| 1 | 最有效 |
| ≥ 2 | 失效方向；因子取值衰减 |

衰减函数（线性、阶梯、或执行单打分里的 3 / 1.5 / 0）不在本文选定。那是统计参数，过 R1/R2/R3 之前不能当权重或门槛。P-4 跟 P-3 一起等 10-19 周检后的 A 类验证，不单独接线。

---

## 哲学指针（无代码）

1. **滞后指标**：「不要用滞后的指标预测下一次波动」支持现有参数纪律 R1 / R2 / R3。盘中追认的参数就是滞后指标。见 `REVIEW_R1_SPEC.md`、`REVIEW_R3_SCAFFOLD.md`、`REVIEW_R4_LOOP.md`。
2. **不追涨**：散户误区是追涨买入、杀跌卖出。JEV 找超跌（低吸）与这条同向。只印证方向，不改 `INDICATORS_WEIGHT_*`。

明确不采用：

| 内容 | 原因 |
|------|------|
| 供需区人工画线（主观克线 / 竭线） | 量化只认上面的固定 K 线规则；未验证前只是候选 |
| 多周期 LTSD（5M / 15M / 1H / 1D / 1W / 1M） | 链上 bar 以 1h 为主，不引入这套周期树 |
| 做空（供给区做空） | 链上 meme 以做多为主；本文不打开空头 |
| 把 RSI / MACD 当主信号 | 书中批判其滞后。指标层继续只作参考输入；主信号仍走因子。RSI/MACD 维持旁路、权重 0 |

---

## 方向校准（M-2，A 类接受前的必过闸）

AQuA（arXiv 2608.12841）：公式即使有预测力，初始符号也可能错。每个 factor_loop 候选——包括本文 P-3 / P-4 / E-1 / G-5，阻断解开后的 I-2，以及日后任何入库候选——都要用**正、反两个符号**各评一次，留下解释更干净的方向（与前向收益同向、IC ≥ 0 的那一侧），然后才谈 A 类 `accepted`。E-1 的两个符号是：回撤到位后反弹，与回撤跌破后加速。G-5 的两个符号是：尖峰后下跌对继续上涨，枯竭后反弹对续跌。I-2 的两个符号是：集中度上升后的 up_1h（吸筹），与集中度上升后的负向（风险 / 回避）。规格见下文「E-1」、「G-5」与「I-2」。I-1 数据阻断已解除，本次仍不把 I-2 送进校准，也不改 `gate_candidate`。

2026-10-14 核对 `review/gates.py` 与 `review/factor_loop.py`：周跑里**还没有**这个闸。有限 IC 只记观察文件，不改 `accepted`。

| 现况 | 说明 |
|------|------|
| `gate_candidate` | 只看 `n_raw`、`unique_token`、`up_1h`。过线则 `status=accepted`。不看符号 |
| `ic_mean` | 来自 `_latest_ic`：整份 `factor_ic_history.csv` 的最后一行，不是该候选自己的双侧 IC，而且经常是 null |
| `calibrate_direction(ic)` | 纯函数。IC 有限时记下 `ic_as_written` 与 `ic_flipped`（= −IC），`kept_sign` 取 IC ≥ 0 的一侧。IC 缺失、非数值或非有限则 **fail closed**（`passed=False`，`blocks_a_class=True`，不登记方向） |
| 观察，不改闸 | 周跑在 IC 有限时调用它，追加 `exports/reports/direction_calibration_observe.jsonl`（正反两符号）。`gate_candidate` **不调用**它，`accepted` 语义不变。缺 IC 就 fail closed 会改掉现在的 `accepted`，所以 `DIRECTION_CALIBRATION_TODO` 仍在 |

`passed=True` 只表示两个符号都记下了，不是接受候选，也不移动 n≥15。不翻 live 权重。`INDICATORS_WEIGHT_*` 保持 0。本段不算有效性。

**信号强度 ≠ 胜率**（PR #46）：见 `INDICATORS_STEP2.md`「设计依据：定价错误（P-4）」和 `INDICATORS_AUDIT.md`「警示事例 → 指标层纪律」。

---

## 艾略特波浪（E-1 / E-4 / E-5）

指标旁路只登记可复算的结构。比率是概率倾向，不是必然（书中：比率分析评定概率而不是必然）。三个回撤标签是同一条回撤假设的三个水平，不是为了凑候选条数再堆研究（Prediction Arena 纪律见文首）。N-1..N-6 是明确拒绝，防止以后把数浪、时间、长周期捡回来。

**E-3（一行，无代码）：** 因子（含 E-1）只做 signal 层辅助确认。下单归决策层确定性规则，风控归 PM 硬规则。斐波那契比率不是独立信号。

**E-2 不在本文。** `target_band_failover`（价格越过目标带后改看下一目标，对照现有 max_hold）归执行 / PM。指标层不登记、不改持仓逻辑。

### E-1 斐波那契回撤

书中的可量化部分：剧烈型调整常回撤至前一段的 61.8% 或 50%；盘档型调整常回撤至 38.2%。链上拉升之后，用波段原语定出「拉升高 → 回撤低」，回撤比例贴近这三个水平时各记一次命中。前向口径对齐 JEV 的 **up_1h**。

| `factor_id`（不 INSERT） | 回撤水平 |
|--------------------------|----------|
| `fib_retrace_0618` | 0.618 |
| `fib_retrace_05` | 0.500 |
| `fib_retrace_0382` | 0.382 |

A 类之前缺一不可，本次都不实现检测器：

1. **M-2 双侧方向校准。** 每个 `factor_id` 都走 `review.gates.calibrate_direction`：回撤到位后的反弹与回撤跌破后的加速各评一次，留下解释更干净的一侧（IC ≥ 0 的 `kept_sign`）。`passed=True` 只表示两个符号都记下了，不是 `accepted`。`gate_candidate` **还不调用**它（见上文方向校准表）。IC 缺失则 fail closed，不登记方向。
2. **M-3 算子化。** 检测器一旦要写，遵守 `INDICATORS_OPERATORIZATION.md`：窗口在 t 收口，禁止日合计 / 未来分母，禁止居中窗口。局部极值不能靠 t 之后的 bar 确认。
3. **滑点 / 成本入回测。** up_1h 对照含成交成本。无成本的 mid 涨跌不算增益。滑点档在执行 `pricing.py`，本文不改档位。
4. **前置：波段原语（下节，TODO）。** 没有 N 根 K 线的局部极值对，E-1 不能算。

周检数字沿用现闸（`review/gates.py`），不新开门槛：n≥15、unique_token≥10；过滤后 1h≥55% 为 pass（连续两周 ≥55% 才考虑激活，本循环最高 `accepted`）；50%–55% 为 `need_retest`；<50% 为 fail（无预测力，`rejected`）。E-1 没有 up_1h 增益就退役，不另写一条比现闸更宽的退役条件。`INDICATORS_WEIGHT_*` 保持 0。

**退役，不恋战。** 链上 meme / 新币个性强、流动性差，波浪形态先天贴合差（书中：商品个性越独立，越不能可靠反映艾略特模式）。E-1 的 up_1h 若无增益，直接退役。不改门槛、不改权重、不改用 N 类内容把故事补圆。

### 波段原语（TODO 依赖，不实现）

| 项 | 说明 |
|----|------|
| 名称 | swing primitive。不是因子，无 `factor_id` |
| 定义 | N 根 K 线内的局部极值对：一侧局部高、一侧局部低。两端都由截止当前 bar 的 OHLC 定出。N 留给原语落地时写明，本文不拍板 |
| 输入 | OHLC。`sources/ccxt` 的 `ccxt_ohlcv` 有 `open / high / low / close`。现网 technical 循环仍多读 `pair_history.price_usd`，缺省把 H/L 当成 close（`INDICATORS_PANDAS_TA.md`）。原语不能直接套在 close 序列上冒充高低点 |
| 因果 | 确认延迟必须在 t 已知。禁止 `center=True` 与 `shift(-k)`（M-3，`INDICATORS_OPERATORIZATION.md`） |
| 状态 | **TODO。** 只登记依赖。不写检测器，不改 `technical_lib`，不改 `decision_engine` |

E-1、E-4、E-5 都挂在这条 TODO 上。原语落地之前不排 factor_loop 实现，也不把 close 序列的伪高低点送进周检。

### E-4 同价位交汇（依赖 E-1）

方法：同一价格上，独立、可复算的结构各算一次命中，用命中数对照单一因子命中。例如回撤 0.618 与另一条已经登记的独立结构同时指向该价，hit-count = 2。书中「多个斐波纳奇关系的交汇更可能是转折」在这里只留下这句可证伪的比较。

与 E-1 同批回测。比较「单因子命中」与「多因子同价命中」的 **up_1h**（同样含滑点 / 成本，同样过 M-2）。**有增益才保留。** 无增益则 E-4 不入库，也不借交汇把无增益的 E-1 留下。

E-4 不是第四个回撤比率，也不把浪 2 / 浪 4 等浪号写进因子。交汇只数已登记、可复算的结构。主观数浪在 N-1，不采用。

依赖：三个 E-1 `factor_id` 与波段原语。原语未实现前，E-4 只停在方法学登记。不单独给 `factor_id`。权重 0。

### E-5 量能确认（观察项，不是新因子）

书中把最大成交量指到第三浪、第五浪量能减小。这里不数浪。观察口径：波段原语定出摆动之后，看成交量斜率，或价格与量能的背离（价格创新高而量能不跟随，或反之）。

数据已经在采集层。`pair_history` 有 `volume_h1` 与 `volume_h24`（`store.py` `_migrate_pair_history`）。这是快照上的回看量，不是自然日合计。使用时遵守 M-3：不得把 `volume_h24` 换成事后才知道的日总量（`INDICATORS_OPERATORIZATION.md`「允许算子」）。

**不新开因子，不给 `factor_id`，不进 `gate_candidate`。** 等波段原语存在后再算斜率 / 背离。没有 up_1h 增益就关闭观察，不升级成因子。权重 0。

### 明确不采用（N-1 .. N-6）

写入本文，防止以后误当成因子或信号。不写检测器，不进看板，不进决策。

| # | 不采用 | 原因 |
|---|--------|------|
| N-1 | 数浪作为核心信号 | 分割点不唯一，同一位置可以给出多个目标。违反确定性规则。只取可复算的回撤与交汇做候选 |
| N-2 | 斐波那契时间序列 / 时间跨度预测 | 书中作者承认还没有确定途径用时间本身做预测 |
| N-3 | 长周期（贝纳 8-9-10 年、康德拉季耶夫约 54 年） | 与链上分钟 / 小时持仓不匹配；周期公式到下一循环可能失效 |
| N-4 | 宏观 / 经济变量（利率、通胀、货币趋势） | 运行层只看行情与已有采集字段，不引入宏观 |
| N-5 | 超级循环浪 / 长期浪级 | 与约 5 分钟–1 小时的持仓周期不匹配 |
| N-6 | 哲学与社会论述 | 无量化落地 |

**meme / 新币是差的艾略特标的。** 个性越独立，波浪模式越不可靠。刚上线的 meme / 新币流动性差、路径个性强，所以 E-1 只是概率倾向候选。up_1h 无增益即退役，不恋战。不因为「理论还没数完」把 N-1..N-6 加回来。

### 与 M-2 / M-3 / 10-19

- **方向：** `calibrate_direction`（`review/gates.py`）。正反两符号都记下才算 M-2 通过。周跑在 IC 有限时只把双侧结果写入观察 jsonl，`gate_candidate` 不调用。交叉见上文「方向校准」，算子全文在 `INDICATORS_OPERATORIZATION.md`。
- **A 类：** 2026-10-19 周检之后，且 M-2 与 M-3 都完成，才把 E-1 送进 A 类验证。此前不是信号。10-19 的 `factor_loop` 只收已经方向校准且已经算子化的候选；这两条没做完，不写 `accepted`。
- 门槛数字不改。不算有效性。权重保持 0。

---

## 江恩换手（G-5）与阻断项（G-7 / G-8）

指标旁路只登记可复算的结构。书中第十章：成交量要按已发售股票总量来衡量；换手骤增而价格滞涨是派发假设，下跌末段换手骤减是卖压出清（第二十一章，执行单 G-15）。这里收成同一族的两个标签，不为凑条数再拆第三个因子。不新增观察 jsonl。不实现检测器。

### 采集核对（#70，2026-10-14 落列）

成交量本来就在 `pair_history`。自 #70（`ca4897b`）起，`pair_history.market_cap` 与 `pair_history.fdv` 和 `volume_h24` 写在同一行；载荷省略、空值或非数字为 NULL，不编造，不用 `fdv` 填 `market_cap`。公式 `volume_h24 / market_cap`（备选同一行 `/ fdv`）必须用这一历史行，禁止拿 `pairs` 上最新市值去配更早的 `volume_h24`。

| 位置 | 实际字段 |
|------|----------|
| `pairs` | 可空 `market_cap`、`fdv`。`upsert_pair` 只写当次 payload。省略、空值或非数字为 NULL。不用 `fdv` 填 `market_cap`。不从旧 `raw_json` 回填 |
| `tokens` | 仍无市值列。一个 token 对多条 pair，对不上某一行的 `volume_h24` |
| `pair_history` | 可空 `market_cap`、`fdv`，与 `price_usd`、`volume_h24`、`volume_h1`、`liquidity_usd`、`txns_h24`、`tier` 同行 |
| Dexscreener pair JSON | 根字段 `marketCap`（别名 `market_cap`）和 `fdv`。`extract_metrics` 抽出可选浮点。`validate_pair` 仍不单独改写这两个键，整对象照旧进 `raw_json` |
| 读法 | `Store.list_pair_history`、`IndicatorStore.load_pair_history`、`load_token_history` 带出 `market_cap` 与 `fdv`。比值只用这一历史行，不用 `pairs` 上最新一次 upsert 去配更早的 `volume_h24` |

检测器仍不实现，公式仍只是候选。`daily_check` 热层检查附带 `mcap_hot_1h`（hot 1h 的 NULL 计数）。该计数不改流动性 PASS/WARN/FAIL。周检计数在 2026-10-19 之后，并且 M-2 与 M-3 都完成后才允许；分母列不再是阻断，M-2 / M-3 / 10-19 仍是。

`volume_h24` / `volume.h24` 是快照时刻的回看量，M-3 允许使用（`INDICATORS_OPERATORIZATION.md`）。不得改成事后才知道的自然日总量。价格腿用已有的 `pair_history.price_usd`。滞涨、尖峰、枯竭的具体倍数本文不拍板，那是统计参数，过 R1/R2/R3 之前不能当门槛。

### G-5 换手率族

| `factor_id`（不 INSERT） | 假设 |
|--------------------------|------|
| `turnover_spike_v0` | 同一历史行 `volume_h24 / market_cap`（备选同一行 `/ fdv`）相对自身近期水平骤增，且 `price_usd` 滞涨。书中的派发假设 |
| `turnover_exhaust_v0` | 下跌之后，同一历史行换手率坍缩。书中的卖压出清。执行单 G-15 是这一条，不另给 id |

派发假设在链上只映射为现金 / 退出倾向。不打开做空（江恩 N-2）。两个标签都对齐 JEV 的 **up_1h**。周检数字沿用现闸（`review/gates.py`），不新开门槛：n≥15、unique_token≥10；过滤后 1h≥55% 为 pass（连续两周 ≥55% 才考虑激活，本循环最高 `accepted`）；50%–55% 为 `need_retest`；<50% 为 fail。`INDICATORS_WEIGHT_*` 保持 0。

A 类之前缺一不可，本次都不实现检测器：

1. **M-2 双侧方向校准。** `turnover_spike_v0`：尖峰后下跌，与尖峰后继续上涨，各评一次。`turnover_exhaust_v0`：枯竭后反弹，与枯竭后续跌，各评一次。留下 IC ≥ 0 的 `kept_sign`。`passed=True` 只表示两个符号都记下了，不是 `accepted`。`gate_candidate` **还不调用**它。IC 缺失则 fail closed。
2. **M-3 算子化。** 窗口在 t 收口。换手分母必须是 t 当时已经知道的市值，禁止用 t 之后才公布的流通盘或当日合计成交量。
3. **分母已落列（#70）。** 快照字段是同一行的 `pair_history.market_cap` 与 `pair_history.fdv`（Dex 省略则为 NULL，不编造）。`pairs` 上的同名列只是最新一次 upsert，不能配更早的 `volume_h24`。检测器仍不实现。列已经在，不再挡住周检；周检仍等 10-19、M-2、M-3。
4. **滑点 / 成本入回测。** up_1h 对照含成交成本。滑点档在执行 `pricing.py`，本文不改档位。

2026-10-19 周检之后，并且 M-2 与 M-3 都完成，才把 G-5 送进 A 类验证。分母列已经在，不再是阻断。此前不是信号、不是仓位、不是止损规则。

周检计数必须用同一历史行上非 NULL 的 `market_cap`（备选同一行 `fdv`）；分母为 NULL 的行跳过；覆盖率只作 10-19 观察，不算有效性。

### G-7 二次突破（阻断，无检测器）

书中（第二十二章）：同一价位第二次创新高比第一次安全。可量化形式是 `breakout_second`：同一区域被突破的次数，或突破后回踩再启。预留 `factor_id` `breakout_second_v0`，**本文不 INSERT**。

**阻断：** 链上「突破」还没有唯一定义。N 根 K 线新高，与历史新高池，两种算法会给出不同的第一次 / 第二次，并且历史池若用到 t 之后的 bar 就是 look-ahead（AQuA）。这与 E-1 的波段原语是同一条 TODO：局部极值必须由截止当前 bar 的 OHLC 定出，N 本文不拍板，原语未实现（见上文「波段原语」）。定义写死并且通过 M-3 之前，不写检测器，不进周检，不入库。权重 0。

### G-8 相对强度（阻断，无检测器）

书中：个股可独立于大盘；强者是大盘跌时它不跌、大盘涨时它领涨。可量化形式是 `rel_strength = token_return / market_avg_return`。预留 `factor_id` `rel_strength_v0`，**本文不 INSERT**。

**阻断：** 「市场基准」还没有定义。全池均值，与对 BTC 收益，是两个不同的分母。采集层有个股 `pair_history.price_usd`，没有选定的市场序列。基准写进变更登记之前，不写检测器，不进周检，不入库。权重 0。

### 江恩明确不采用（Gann N-1 .. N-6）

与上文艾略特 N-1..N-6 **不是同一张表**。编号沿用江恩执行单，防止以后把案例、做空、画线、日历、时间预言、期货章节当成因子。不写检测器，不进看板，不进决策，不新增观察 jsonl。

| # | 不采用 | 原因 |
|---|--------|------|
| N-1 | 1920 年代美股 / 期货具体案例（铁路、工业、棉花的历史点位与牛熊复盘表） | 做市与周 / 月周期和链上 5 分钟–1 小时不匹配。只取可量化原语 |
| N-2 | 做空文化 | 链上现货无做空通道。派发只映射为现金 / 退出，不引入做空 |
| N-3 | 人工判图 / 画线 | 图是可视化，不是人工判读输入。走确定性规则 |
| N-4 | 1920 年代日历效应（周一、大选） | 加密 7×24，无交易日 / 大选。周末流动性只可作 C 类观察，不在本文立项 |
| N-5 | 时间因素预测 / 年度预测 | 作者未给出可复现方法。只信可回测因子 |
| N-6 | 期货章节（棉花 / 小麦 / 玉米，第四部） | 与链上现货无关 |

本书不含后来被神化的角度线 / 正方 / 轮中轮。那些预测工具同样不采用。纪律层的价值不在指标候选表里改代码。

---

## 持币集中度（I-2，数据阻断已解除，未入库）

指标旁路登记 I-2。它把集中度变化收成可回测的 factor_loop 候选，不是人工判断，也不是本次检测器。输入是 I-1 的 `top10_share`。采集层 [#79](https://github.com/tspike630/trade/pull/79) 已写入 `address_labels`、`token_holder_snapshots`、`token_transfer_edges`。指标侧 `indicators/holder_metrics.py` 只读计算 `top10_share` 与 `dev_balance_delta`。空输入与算不出的快照是 NULL，不编造持仓。本次不写检测器，不进周检，不 INSERT，不新增观察 jsonl，不改 `decision_engine`，不改 `gate_candidate` / `accepted`。权重 0。不算有效性。A 类仍要 **10-19** 周检，并且 **M-2** 与 **M-3** 都完成。过门槛不自动激活。

### I-2 集中度族（登记，未检测）

| `factor_id`（不 INSERT） | 定义 |
|--------------------------|------|
| `concentration_top10_v0` | top10 holder 占比。横截面风险：占比高 = 筹码集中 |
| `concentration_delta_v0` | 该占比的 24h 变化。时间序列上读作吸筹或派发，符号由 M-2 留下更干净的一侧 |

`hhi_index`（持币赫芬达尔指数）是 `concentration_top10` 的**备选**，不是第三个因子。日后与 top10 二选一验证。验证前不给入库 `factor_id`，不实现，不进周检。

两个标签都对齐 JEV 的 **up_1h**。周检数字沿用现闸（`review/gates.py`），不新开门槛。双门槛是 n≥15、unique_token≥10、过滤后 1h≥55%（连续两周 ≥55% 才考虑激活，本循环最高 `accepted`）；50%–55% 为 `need_retest`；<50% 为 fail。`INDICATORS_WEIGHT_*` 保持 0。

**M-2 双侧。** 集中度上升后的 up_1h（吸筹），与集中度上升后的负向（风险 / 回避），各评一次。留下 IC ≥ 0 的 `kept_sign`。`passed=True` 只表示两个符号都记下了，不是 `accepted`。负向一侧是回避 / 现金，不因此打开做空（江恩 N-2 仍不采用）。数据阻断已解除，本次仍不跑这次校准，也不把结果写进新的观察 jsonl。

`concentration_top10` 读单次快照的 `top10_share`。`concentration_delta` 读 `top10_share_history`：同一代币上、窗口在 t 收口的两个时点之差。历史还没有覆盖到所要的窗口时，变化保持 NULL。单次快照不是 24h 变化。不写检测器，不进周检，不 INSERT `factor_candidates.db`，不新增观察 jsonl，不改 `decision_engine`，不改 `gate_candidate` / `accepted`。权重 0。

24h 变化一旦要算，遵守 M-3（`INDICATORS_OPERATORIZATION.md`）：窗口在 t 收口，持仓快照必须是 t 当时已经知道的，禁止用 t 之后的 holder 名单。滑点 / 成本入回测的要求与 E-1 / G-5 相同，本文不改档位。10-19 之后、M-2 与 M-3 都完成，才谈把 I-2 送进 A 类。此前不是信号、不是仓位、不是止损规则。过门槛不自动激活。

### I-1 只读公式（数据阻断已解除）

`dev_balance_delta` 与 `top10_share` 在 `indicators/holder_metrics.py`。采集表由 #79 写入。本模块只读，不创建表，不写采集器。空输入与无法复算的行是 NULL。

| 名称 | 公式 | 状态 |
|------|------|------|
| `dev_balance_delta` | 标签为 `dev` 的地址上的净流量：转入合计减转出合计。正 = 净流入（吸筹候选假设），负 = 净流出（出货预警假设）。dev 到 dev 的边两边抵消。`amount_ui` 为 NULL 的边跳过，不当成 0。没有碰到这些地址的可用边时，改看 holder 快照余额：同一地址至少两个有限余额，取最后减最早；没进 top10 的地址不当成 0。有可用转账边时不用余额，避免加总两次。两边都没有则 NULL | **只读。** 不入库 |
| `top10_share` | 单次快照里 rank 1..10 的持仓占供应之比。供应唯一且每行 `amount_ui` 都有时用 `sum(amount_ui) / total_supply_ui`。否则每行 `pct_of_supply` 都有则把占比相加。任一行两种都没有、供应互相冲突、或空快照，整次为 NULL。少于 10 行时只加已有的行，不补零。`top10_share_history` 按 `snapshot_id` 给出序列，算不出的点保持 NULL | **只读。** I-2 的 `concentration_top10` 读这一列 |

阈值，以及「dev 净流出后 1h 下跌」对拍，是统计参数，走 R2/R3。不在本文当门槛。不算有效性。

### INTEL_LOOP（无代码）

周检时可以按缺口扫描模板填「有数据可算但没算」的空缺。AI 提出的候选 ≠ 自动生效：先登记，走 R2（有依据 + 登记），周检 R3 之后才谈激活。双门槛不因来源是 AI 而放松（n≥15 / unique≥10 / 1h≥55%）。本次不写扫描脚本，不新增自动化，不新增观察 jsonl。

### I-3 / I-4 不在指标层

`bot_trade_share` / `slippage_1h`（I-3，执行质量）与 OTC / 解锁时间表（I-4，登记）归执行 / registry。指标层不登记、不实现、不建表。

---

## 不算有效性

- 未接入 `decision_engine`，未注册进 `FACTOR_GETTERS`，未进 composite。E-1 的三个 `factor_id` 与 G-5 的 `turnover_spike_v0` / `turnover_exhaust_v0` 未 INSERT。G-7 / G-8 未 INSERT。I-2 的 `concentration_top10_v0` / `concentration_delta_v0` 未 INSERT。`hhi_index` 未入库。波段原语未实现。G-5 分母已落列（#70，同一行 `pair_history.market_cap` / `fdv`，省略为 NULL），检测器未实现。I-1 的表在采集层（#79）；`top10_share` / `dev_balance_delta` 只在指标侧只读计算，不写回业务表。
- 权重保持 0。10-19 周检出数之前，不把 P-3 / P-4 / E-1 / G-5 / I-2 写成有效因子，也不实现检测器。E-4 无 up_1h 增益不保留。E-5 保持观察，不升级。G-7 / G-8 在阻断解开前不是候选实现。I-2 的数据阻断已解除，检测器仍不实现，也不入库。
- A 类只在 **10-19 及之后**，并且 **M-2**（`calibrate_direction`，正反两符号）与 **M-3**（算子化）都完成后才谈。G-5 分母已落列，仍不因此入库或改权重。I-2 可以读 `top10_share` 历史，历史未覆盖的窗口仍是 NULL；这不提前 A 类，也不改权重。回测依据要含滑点 / 成本，并做变更登记。缺校准不写 `accepted`。`calibrate_direction` 已可调用。周跑只在 IC 有限时把双侧结果写入既有观察文件，仍不接到 `gate_candidate`（见上表）。本次不新增观察 jsonl。过门槛仍不自动激活策略（`factor_loop` 既有约束）。AI 候选同样不自动激活（R2/R3）。
- 艾略特 N-1..N-6 不采用。江恩 N-1..N-6 不采用。E-2 归执行 / PM，不在指标层。E-3：因子只辅助确认，决策与 PM 硬规则拥有下单与风控。I-3 / I-4 归执行 / registry，不在指标层。
- ALPHA_DECAY（2026-10-16）只观察：衰减两因是假因子与拥挤，只登记衰减风险。不写实锤，也不下证伪判决，不把 JEV 写成已被判决。M-A1..A6 不进登记表；M-A5 / M-A6 只是设计候选 / 先决观察。权重保持 0。
